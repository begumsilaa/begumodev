def topla(a, b):
    return a + b

def cikar(a, b):
    return a - b

def carp(a, b):
    return a * b

def bol(a, b):
    if b != 0:
        return a / b
    else:
        return "Sıfıra bölme hatası!"

def main():
    print("Yapmak istediğiniz işlemi seçin:")
    print("1: Topla")
    print("2: Çıkar")
    print("3: Çarp")
    print("4: Böl")

    secim = input("Hangi işlemi yapmak istersiniz (1/2/3/4)? ")

    sayi1 = float(input("Birinci sayıyı girin: "))
    sayi2 = float(input("İkinci sayıyı girin: "))

    if secim == '1':
        print("Sonuç:", topla(sayi1, sayi2))
    elif secim == '2':
        print("Sonuç:", cikar(sayi1, sayi2))
    elif secim == '3':
        print("Sonuç:", carp(sayi1, sayi2))
    elif secim == '4':
        print("Sonuç:", bol(sayi1, sayi2))
    else:
        print("Geçersiz seçim!")

if __name__ == "__main__":
    main()
